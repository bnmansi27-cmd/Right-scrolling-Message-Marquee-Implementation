#ifndef MAIN_H
#define MAIN_H

/* The pin map for CLCD, Using 4 Bit mode with RW grounded */
#define D4      18
#define D5      5
#define D6      17
#define D7      16
#define RS      22
#define EN      21

#endif
